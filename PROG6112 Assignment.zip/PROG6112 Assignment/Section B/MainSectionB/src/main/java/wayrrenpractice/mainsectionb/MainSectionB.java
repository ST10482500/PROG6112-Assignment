/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package wayrrenpractice.mainsectionb;
import java.util.Scanner;
/**
 *
 * @author User
 */
public class MainSectionB {
private static GroceryList groceryList = new GroceryList();
    private static Scanner scanner = new Scanner(System.in);
    private static int idCounter = 1;

    public static void main(String[] args) {
        boolean running = true;

        while (running) {
            System.out.println("\n==== GROCERY LIST MANAGER ====");
            System.out.println("1. Add Item");
            System.out.println("2. View Items");
            System.out.println("3. Search Item");
            System.out.println("4. Update Item");
            System.out.println("5. Delete Item");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = readIntSafe();
            switch (choice) {
                case 1:
                    addItem();
                    break;
                case 2:
                    viewItems();
                    break;
                case 3:
                    searchItem();
                    break;
                case 4:
                    updateItem();
                    break;
                case 5:
                    deleteItem();
                    break;
                case 6:
                    running = false;
                    break;
                default:
                    System.out.println("Invalid choice, try again.");
            }
        }
        System.out.println("Exiting Grocery List Manager. Goodbye!");
    }

    private static void addItem() {
        System.out.print("Enter item name: ");
        String name = scanner.nextLine().trim();

        System.out.print("Enter quantity: ");
        int quantity = readIntSafe();

        GroceryItem item = new GroceryItem(idCounter++, name, quantity);
        groceryList.addItem(item);
        System.out.println("Item added successfully! ID = " + item.getId());
    }

    private static void viewItems() {
        if (groceryList.getItems().isEmpty()) {
            System.out.println("No items in the list.");
            return;
        }
        System.out.println("\n---- Items ----");
        for (GroceryItem item : groceryList.getItems()) {
            System.out.println(item);
        }
    }

    private static void searchItem() {
        System.out.print("Enter item ID to search: ");
        int id = readIntSafe();
        GroceryItem item = groceryList.findItemById(id);
        if (item != null) {
            System.out.println("Found: " + item);
        } else {
            System.out.println("Item not found.");
        }
    }

    private static void updateItem() {
        System.out.print("Enter item ID to update: ");
        int id = readIntSafe();
        GroceryItem item = groceryList.findItemById(id);
        if (item == null) {
            System.out.println("Item not found.");
            return;
        }

        System.out.print("Enter new name: ");
        String newName = scanner.nextLine().trim();
        System.out.print("Enter new quantity: ");
        int newQty = readIntSafe();

        groceryList.updateItem(id, newName, newQty);
        System.out.println("Item updated successfully!");
    }

    private static void deleteItem() {
        System.out.print("Enter item ID to delete: ");
        int id = readIntSafe();
        boolean ok = groceryList.removeItemById(id);
        if (ok) System.out.println("Item deleted.");
        else System.out.println("Item not found.");
    }

    // helper to safely read integers
    private static int readIntSafe() {
        while (true) {
            try {
                String line = scanner.nextLine().trim();
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.print("Invalid number — try again: ");
            }
        }
    }
}

   
        
    

