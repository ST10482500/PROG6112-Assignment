/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.mainsectionb;
import java.util.ArrayList;
/**
 *
 * @author User
 */
public class GroceryList {
  


    private ArrayList<GroceryItem> items = new ArrayList<>();

    public void addItem(GroceryItem item) {
        items.add(item);
    }

    public ArrayList<GroceryItem> getItems() {
        return items;
    }

    public GroceryItem findItemById(int id) {
        for (GroceryItem item : items) {
            if (item.getId() == id) return item;
        }
        return null;
    }

    public boolean removeItemById(int id) {
        GroceryItem item = findItemById(id);
        if (item != null) {
            items.remove(item);
            return true;
        }
        return false;
    }

    public boolean updateItem(int id, String newName, int newQuantity) {
        GroceryItem item = findItemById(id);
        if (item != null) {
            item.setName(newName);
            item.setQuantity(newQuantity);
            return true;
        }
        return false;
    }
}
 

