/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package wayrrenpractice.mainsectionb;

import java.util.ArrayList;
import static org.testng.Assert.*;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 *
 * @author User
 */
public class GroceryListNGTest {
    
    public GroceryListNGTest() {
    }

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @BeforeMethod
    public void setUpMethod() throws Exception {
    }

    @AfterMethod
    public void tearDownMethod() throws Exception {
    }

    /**
     * Test of addItem method, of class GroceryList.
     */
    @Test
    public void testAddItem() {
        System.out.println("addItem");
        GroceryItem item = null;
        GroceryList instance = new GroceryList();
        instance.addItem(item);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getItems method, of class GroceryList.
     */
    @Test
    public void testGetItems() {
        System.out.println("getItems");
        GroceryList instance = new GroceryList();
        ArrayList expResult = null;
        ArrayList result = instance.getItems();
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of findItemById method, of class GroceryList.
     */
    @Test
    public void testFindItemById() {
        System.out.println("findItemById");
        int id = 0;
        GroceryList instance = new GroceryList();
        GroceryItem expResult = null;
        GroceryItem result = instance.findItemById(id);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of removeItemById method, of class GroceryList.
     */
    @Test
    public void testRemoveItemById() {
        System.out.println("removeItemById");
        int id = 0;
        GroceryList instance = new GroceryList();
        boolean expResult = false;
        boolean result = instance.removeItemById(id);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateItem method, of class GroceryList.
     */
    @Test
    public void testUpdateItem() {
        System.out.println("updateItem");
        int id = 0;
        String newName = "";
        int newQuantity = 0;
        GroceryList instance = new GroceryList();
        boolean expResult = false;
        boolean result = instance.updateItem(id, newName, newQuantity);
        assertEquals(result, expResult);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
