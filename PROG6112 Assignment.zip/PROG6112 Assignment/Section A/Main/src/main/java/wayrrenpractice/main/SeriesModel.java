/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.main;

/**
 *
 * @author User
 */
public class SeriesModel {
  private String id;
    private String seriesName;
    private String seriesAge;
    private String seriesNumberOfEpisodes;

    public SeriesModel(String id, String seriesName, String seriesAge, String seriesNumberOfEpisodes) {
        this.id = id;
        this.seriesName = seriesName;
        this.seriesAge = seriesAge;
        this.seriesNumberOfEpisodes = seriesNumberOfEpisodes;
    }

    // Getters & setters
    public String getId() { return id; }
    public String getSeriesName() { return seriesName; }
    public void setSeriesName(String seriesName) { this.seriesName = seriesName; }
    public String getSeriesAge() { return seriesAge; }
    public void setSeriesAge(String seriesAge) { this.seriesAge = seriesAge; }
    public String getSeriesNumberOfEpisodes() { return seriesNumberOfEpisodes; }
    public void setSeriesNumberOfEpisodes(String seriesNumberOfEpisodes) { this.seriesNumberOfEpisodes = seriesNumberOfEpisodes; }
}
  

