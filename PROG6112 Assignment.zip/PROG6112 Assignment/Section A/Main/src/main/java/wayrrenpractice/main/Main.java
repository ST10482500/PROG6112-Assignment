/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package wayrrenpractice.main;

/**
 *
 * @author User
 */
public class Main {

    public static void main(String[] args) {
    Series app = new Series();
        app.showMenu();
    }
}

        
    
   
