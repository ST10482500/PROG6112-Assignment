/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wayrrenpractice.main;
import java.util.*;
/**
 *
 * @author User
 */
public class Series {
 private final Scanner sc = new Scanner(System.in);
    private final List<SeriesModel> seriesList = new ArrayList<>();

    public void showMenu() {
        while (true) {
            System.out.println("\nLATEST SERIES 2025");
            System.out.println("1. Capture a new series");
            System.out.println("2. Search for a series");
            System.out.println("3. Update series");
            System.out.println("4. Delete a series");
            System.out.println("5. Print series report");
            System.out.println("6. Exit");
            System.out.print("Choose: ");

            String choice = sc.nextLine().trim();
            switch (choice) {
                case "1" -> captureSeries();
                case "2" -> searchSeries();
                case "3" -> updateSeries();
                case "4" -> deleteSeries();
                case "5" -> printReport();
                case "6" -> {
                    System.out.println("Exiting... Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice!");
            }
        }
    }

    private void captureSeries() {
      System.out.print("Enter series id: ");
        String id = sc.nextLine().trim();

      System.out.print("Enter series name: ");
        String name = sc.nextLine().trim();

        int age = readValidAge();
        int episodes = readPositiveInt("Enter number of episodes: ");

        seriesList.add(new SeriesModel(id, name, String.valueOf(age), String.valueOf(episodes)));
     System.out.println("✅ Series captured successfully!");
    }

   private void searchSeries() {
     System.out.print("Enter series id to search: ");
        String id = sc.nextLine().trim();
        SeriesModel s = findById(id);

        if (s == null) {
            System.out.println("❌ Series not found!");
        } else {
            printDetails(s);
        }
    }

    private void updateSeries() {
        System.out.print("Enter series id to update: ");
        String id = sc.nextLine().trim();
        SeriesModel s = findById(id);

        if (s == null) {
            System.out.println("❌ Series not found!");
            return;
        }

        System.out.print("Enter new name: ");
        s.setSeriesName(sc.nextLine().trim());

        int age = readValidAge();
        s.setSeriesAge(String.valueOf(age));

        int episodes = readPositiveInt("Enter new number of episodes: ");
        s.setSeriesNumberOfEpisodes(String.valueOf(episodes));

        System.out.println("✅ Series updated successfully!");
    }

    private void deleteSeries() {
        System.out.print("Enter series id to delete: ");
        String id = sc.nextLine().trim();
        SeriesModel s = findById(id);

        if (s == null) {
            System.out.println("❌ Series not found!");
            return;
        }

        System.out.print("Are you sure you want to delete? (y/yes): ");
        String confirm = sc.nextLine().trim().toLowerCase();
        if (confirm.equals("y") || confirm.equals("yes")) {
            seriesList.remove(s);
            System.out.println("🗑️ Series deleted!");
        } else {
            System.out.println("❌ Delete cancelled.");
        }
    }

    private void printReport() {
        if (seriesList.isEmpty()) {
            System.out.println("No series found.");
            return;
        }

        System.out.println("\n--- SERIES REPORT 2025 ---");
        for (SeriesModel s : seriesList) {
            printDetails(s);
        }
    }

    // -------- Helpers --------
  private SeriesModel findById(String id) {
      for (SeriesModel s : seriesList) {
            if (s.getId().equals(id)) return s;
        }
        return null;
    }

    private void printDetails(SeriesModel s) {
       System.out.println("ID: " + s.getId());
       System.out.println("Name: " + s.getSeriesName());
       System.out.println("Age Restriction: " + s.getSeriesAge());
       System.out.println("Episodes: " + s.getSeriesNumberOfEpisodes());
        System.out.println("---------------------------");
    }

    private int readValidAge() {
        while (true) {
            System.out.print("Enter age restriction (2–18): ");
            try {
                int age = Integer.parseInt(sc.nextLine().trim());
                if (age >= 2 && age <= 18) return age;
               System.out.println("❌ Invalid age! Must be 2–18.");
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Numbers only.");
            }
        }
    }

   private int readPositiveInt(String msg) {
        while (true) {
            System.out.print(msg);
            try {
                int val = Integer.parseInt(sc.nextLine().trim());
                if (val > 0) return val;
                System.out.println("❌ Must be a positive number.");
            } catch (NumberFormatException e) {
                System.out.println("❌ Invalid input! Numbers only.");
            }
        }
    }
}


